# UNIGO – Bus Finder

Part of **UNIGO**, a campus guide website for Graphic Era University (B.Tech PBL project).
This folder is the Bus Finder feature on its own: it has its own frontend, backend and data, and runs by itself.

**Made by:** Anushka

## What it does
Type a destination (a full name, part of a name, or even a misspelled name such as "gadi") and see where the college bus leaves from, its three shift timings and the next bus today.

## How to run it
You need **g++** (MinGW on Windows) and a web browser.

**In VS Code:** open this folder, then *Terminal → Run Task… → UNIGO: Run server*, and open http://localhost:8080

**Or in a terminal, from this folder:**
```
g++ -std=c++14 -O2 -Wall -o backend/unigo_server.exe backend/server.cpp -lws2_32
backend\unigo_server.exe 8080 frontend data
```
Then open http://localhost:8080 . On Linux/macOS leave out `-lws2_32` and `.exe`.

Try it: Search `isbt`, `clock tower`, `chowk` (several results) or `gadi` (spelling help).

## Concepts used
- Class BusStop (encapsulation, std::array of 3 shifts)
- Hash tables (unordered_map) for exact search
- Trie for prefix search / autocomplete
- Edit distance (dynamic programming) for spelling mistakes
- Sound keys for Hindi spellings (gadi -> Garhi Cantt)
- Sorted std::map of departure points
- Reloads the CSV when it changes, keeping the old data if the new file is broken

## Files
```
.gitignore
.vscode/tasks.json
README.md
UNIGO_Bus_Dataset_Clean_Final.xlsx
backend/bus_database.h
backend/bus_stop.h
backend/data_store.h
backend/handlers.h
backend/http.h
backend/json_writer.h
backend/search_index.h
backend/server.cpp
backend/static_files.h
backend/text_utils.h
backend/trie.h
data/stops.csv
frontend/css/style.css
frontend/index.html
frontend/js/app.js
tools/xlsx_to_csv.py
```

Frontend: HTML, CSS, JavaScript. Backend: C++14 with the standard library only (no external libraries).
Students' data created while using the site (accounts, posts, photos, reviews) is listed in `.gitignore` and must not be uploaded.
