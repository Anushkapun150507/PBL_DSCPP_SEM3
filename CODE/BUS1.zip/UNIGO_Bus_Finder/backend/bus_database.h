// bus_database.h -- owns every BusStop. Searching is done by the shared SearchIndex
// (search_index.h), the same engine used by the Campus Map and the Classroom Finder.
#pragma once
#include <fstream>
#include <map>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>
#include "bus_stop.h"
#include "search_index.h"
#include "text_utils.h"

namespace unigo {

class BusDatabase {
public:
    // Expected columns: Place, Departure From, 1st Shift, 2nd Shift, 3rd Shift (first line = header).
    void loadCsv(const std::string& path) {
        std::ifstream f(path);
        if (!f) throw std::runtime_error("Cannot open " + path);
        std::string line;
        std::getline(f, line);                                         // skip the header row
        while (std::getline(f, line)) {
            if (trim(line).empty()) continue;
            std::vector<std::string> c = parseCsvLine(line);
            for (std::string& cell : c) cell = trim(cell);
            if (c.size() < 5 || c[0].empty() || c[1].empty()) { ++skipped_; continue; }   // incomplete row
            add(BusStop(c[0], c[1], {{c[2], c[3], c[4]}}));
        }
        if (stops_.empty()) throw std::runtime_error("No valid rows found in " + path);
    }

    void add(BusStop s) {
        int id = (int)stops_.size();
        index_.add(id, {s.place()});                  // hash tables + tries, inside SearchIndex
        byDeparture_[s.departFrom()].push_back(id);   // sorted map: departure point -> ids
        stops_.push_back(std::move(s));
    }

    // Every matching stop, best match first, no duplicates (exact -> prefix -> contains).
    std::vector<const BusStop*> search(const std::string& query) const {
        std::vector<const BusStop*> out;
        for (int id : index_.search(query)) out.push_back(&stops_[id]);
        return out;
    }

    // "Did you mean?" for typos: up to k place names closest to the query (each name listed once).
    std::vector<std::string> didYouMean(const std::string& query, size_t k = 5) const {
        std::vector<std::string> out;
        std::unordered_set<std::string> seen;
        for (int id : index_.didYouMean(query, k))
            if (seen.insert(normalize(stops_[id].place())).second) out.push_back(stops_[id].place());
        return out;
    }

    std::vector<std::string> departurePoints() const {        // already sorted: std::map is ordered
        std::vector<std::string> v;
        for (const auto& kv : byDeparture_) v.push_back(kv.first);
        return v;
    }

    std::vector<const BusStop*> stopsAt(const std::string& departure) const {
        std::vector<const BusStop*> out;
        auto it = byDeparture_.find(departure);
        if (it == byDeparture_.end()) return out;
        for (int id : it->second) out.push_back(&stops_[id]);
        return out;
    }

    size_t size() const { return stops_.size(); }
    int skippedRows() const { return skipped_; }

private:
    std::vector<BusStop> stops_;                                   // the single source of truth
    SearchIndex index_;                                            // shared search engine
    std::map<std::string, std::vector<int>> byDeparture_;
    int skipped_ = 0;
};

} // namespace unigo
