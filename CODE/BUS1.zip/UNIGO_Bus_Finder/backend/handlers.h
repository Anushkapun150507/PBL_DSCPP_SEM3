// handlers.h -- Bus Finder: one class per URL. Each inherits RequestHandler and overrides handle().
// (The handler for the website's own files, StaticFileHandler, is in static_files.h.)
#pragma once
#include <ctime>
#include <string>
#include "data_store.h"
#include "http.h"
#include "json_writer.h"
#include "static_files.h"

namespace unigo {

inline int nowMinutes() {
    std::time_t t = std::time(nullptr);
    std::tm* lt = std::localtime(&t);
    return lt->tm_hour * 60 + lt->tm_min;
}

// GET /api/search?q=<destination>  ->  every matching stop with its boarding point and timings.
// When nothing matches, "didYouMean" lists the closest real place names (typo help).
class SearchHandler : public RequestHandler {
public:
    explicit SearchHandler(DataStore& store) : store_(store) {}

    HttpResponse handle(const HttpRequest& req) override {
        const std::string raw = req.param("q");
        const std::string q = normalize(raw);
        if (q.empty()) return HttpResponse::error(400, "empty_query", "Please enter a destination to search.");
        if (!isValidQuery(raw))
            return HttpResponse::error(400, "invalid_query",
                "Destination names can only contain letters, numbers and basic punctuation (max 60 characters).");

        const BusDatabase& db = store_.db();
        std::vector<const BusStop*> results = db.search(q);
        const int now = nowMinutes();

        JsonWriter j;
        j.beginObject().key("query").str(trim(raw)).key("count").num((long long)results.size());
        j.key("results").beginArray();
        for (const BusStop* s : results) writeStop(j, *s, q, now);
        j.endArray();
        j.key("didYouMean").beginArray();
        if (results.empty()) for (const std::string& name : db.didYouMean(q)) j.str(name);
        j.endArray().endObject();
        return HttpResponse::json(j.text());
    }

private:
    static void writeStop(JsonWriter& j, const BusStop& s, const std::string& normQuery, int now) {
        static const char* LABELS[BusStop::SHIFTS] = {"1st Shift", "2nd Shift", "3rd Shift"};
        const int next = s.nextShift(now);
        j.beginObject()
            .key("place").str(s.place())
            .key("departureFrom").str(s.departFrom())
            .key("exactMatch").boolean(normalize(s.place()) == normQuery)
            .key("shifts").beginArray();
        for (int i = 0; i < BusStop::SHIFTS; ++i) {
            const bool missing = s.shift(i).empty();
            j.beginObject()
                .key("label").str(LABELS[i])
                .key("time").str(missing ? "Not available" : s.shift(i))
                .key("runs").boolean(s.runsIn(i))
                .key("next").boolean(i == next)
                .endObject();
        }
        j.endArray().key("nextBus");
        if (next >= 0) j.str(s.shift(next)); else j.null();
        j.endObject();
    }

    DataStore& store_;   // composition by reference: the handler uses the store, it doesn't own it
};

// GET /api/suggest?q=<text>  ->  up to 8 place names for the autocomplete dropdown.
class SuggestHandler : public RequestHandler {
public:
    explicit SuggestHandler(DataStore& store) : store_(store) {}

    HttpResponse handle(const HttpRequest& req) override {
        const std::string raw = req.param("q");
        JsonWriter j;
        j.beginObject().key("suggestions").beginArray();
        if (!normalize(raw).empty() && isValidQuery(raw)) {
            std::vector<const BusStop*> res = store_.db().search(raw);
            for (size_t i = 0; i < res.size() && i < 8; ++i) j.str(res[i]->place());
            if (res.empty())                                   // nothing as typed: offer the closest names instead
                for (const std::string& name : store_.db().didYouMean(raw, 5)) j.str(name);
        }
        j.endArray().endObject();
        return HttpResponse::json(j.text());
    }

private:
    DataStore& store_;
};

// GET /api/meta  ->  how many places are loaded and the list of departure points.
class MetaHandler : public RequestHandler {
public:
    explicit MetaHandler(DataStore& store) : store_(store) {}

    HttpResponse handle(const HttpRequest&) override {
        const BusDatabase& db = store_.db();
        JsonWriter j;
        j.beginObject().key("places").num((long long)db.size()).key("departurePoints").beginArray();
        for (const std::string& p : db.departurePoints()) j.str(p);
        j.endArray().endObject();
        return HttpResponse::json(j.text());
    }

private:
    DataStore& store_;
};

} // namespace unigo
