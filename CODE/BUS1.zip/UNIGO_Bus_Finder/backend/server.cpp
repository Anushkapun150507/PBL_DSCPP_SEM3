// server.cpp -- UNIGO Bus Finder, on its own. Wires the pieces together and starts the web server.
//
//   GET /api/search?q=      -> matching places, boarding point, 3 shifts, next bus
//   GET /api/suggest?q=     -> up to 8 names for autocomplete
//   GET /api/meta           -> number of places and departure points
//   anything else           -> files from the frontend folder (index.html, css, js)
//
// Usage: backend/unigo_server.exe [port=8080] [frontendDir=frontend] [dataDir=data]
// Then open http://localhost:8080 in the browser.
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include "handlers.h"

using namespace unigo;

int main(int argc, char** argv) {
    const int port = argc > 1 ? std::atoi(argv[1]) : 8080;
    const std::string frontendDir = argc > 2 ? argv[2] : "frontend";
    const std::string dataDir = std::string(argc > 3 ? argv[3] : "data") + "/";
    if (port < 1 || port > 65535) { std::cerr << "Invalid port number.\n"; return 1; }
    if (!std::ifstream(frontendDir + "/index.html")) {
        std::cerr << "Cannot find " << frontendDir << "/index.html -- run this from the project folder.\n";
        return 1;
    }

    // The bus timetable, reloaded automatically when data/stops.csv changes.
    DataStore store(dataDir + "stops.csv");
    if (!store.reload(true)) return 1;

    NetworkSession net;
    if (!net.ok()) { std::cerr << "Could not start networking.\n"; return 1; }

    HttpServer server;
    auto h = [](RequestHandler* p) { return std::unique_ptr<RequestHandler>(p); };
    server.addRoute("/api/search", h(new SearchHandler(store)));
    server.addRoute("/api/suggest", h(new SuggestHandler(store)));
    server.addRoute("/api/meta", h(new MetaHandler(store)));
    server.setFallback(h(new StaticFileHandler(frontendDir)));

    std::string error;
    if (!server.listen("127.0.0.1", port, error)) { std::cerr << "Could not start: " << error << "\n"; return 1; }
    std::cout << "UNIGO Bus Finder running. Open http://localhost:" << port << " in your browser (Ctrl+C to stop)" << std::endl;
    server.run();
}
